# 🍳 AI Recipe Multi-Agent System

An intelligent recipe management system powered by multiple specialized AI agents built with Python and Streamlit.

## 📋 Features

- **👨‍🍳 Recipe Generator Agent** - Creates recipes based on your ingredients, dietary restrictions, and cuisine preferences
- **🥗 Nutritionist Agent** - Analyzes calorie content, calculates health scores, and provides nutritional recommendations
- **📋 Chef Assistant Agent** - Scales recipes, suggests ingredient substitutions, and generates shopping lists
- **🔄 Full Workflow** - Runs all agents in sequence for complete recipe creation pipeline

## 🚀 Installation & Setup

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Step 1: Install Dependencies
```bash
pip install streamlit
```

### Step 2: Run the Application
```bash
streamlit run streamlit_app.py
```

The application will automatically open in your default browser at `http://localhost:8501`

## 📁 Project Structure

```
Recipe_Multi_Agent_System/
├── agent.py                  # Original backend agent logic
├── multi_agent_recipe.py     # Multi-agent orchestrator system
├── streamlit_app.py          # Streamlit web interface
├── .env                      # Configuration file
├── recipes.db                # SQLite database for recipes
└── README.md                 # This file
```

## 🎯 How to Use

### 1. Generate a Recipe
- Navigate to "👨‍🍳 Recipe Generator"
- Enter ingredients (include/exclude)
- Select cuisine type and dietary restrictions
- Click "Generate Recipe"

### 2. Analyze Nutrition
- Navigate to "🥗 Nutritionist"
- Select a saved recipe
- Click "Analyze Nutrition" to see calorie breakdown and health score

### 3. Use Chef Assistant
- Navigate to "📋 Chef Assistant"
- Choose a task:
  - **Scale Recipe** - Adjust servings
  - **Find Substitutions** - Get ingredient alternatives
  - **Generate Shopping List** - Create shopping list from recipe

### 4. Full Workflow
- Navigate to "🔄 Full Workflow"
- Enter recipe parameters
- Run complete workflow to generate, analyze, and create shopping list in one go

## 💾 Database

The system uses SQLite to store recipes locally in `recipes.db`. All your recipes are saved automatically and persist between sessions.

## 🛠️ Technical Details

- **Framework**: Streamlit
- **Database**: SQLite
- **Language**: Python 3.13.7
- **Architecture**: Multi-agent system with specialized agents

## 📝 License

This project is open source and available for educational purposes.

## 🤝 Contributing

Feel free to fork this project and submit pull requests for improvements!

---
Made with ❤️ using Python and Streamlit
