import streamlit as st
import json
from typing import Dict, Any
import sys
import os

# Import the multi-agent system (assuming it's in the same directory)
# from multi_agent_recipe import RecipeAgentOrchestrator, IngredientDC, RecipeCreateDC

# For standalone demo, include necessary imports
from dataclasses import asdict

# You would import from your multi_agent_recipe.py file
# For this demo, we'll assume the classes are available

st.set_page_config(
    page_title="AI Recipe Multi-Agent System",
    page_icon="👨‍🍳",
    layout="wide"
)

# Initialize session state
if 'orchestrator' not in st.session_state:
    try:
        from multi_agent_recipe import RecipeAgentOrchestrator
        st.session_state.orchestrator = RecipeAgentOrchestrator()
    except ImportError:
        st.error("Please ensure multi_agent_recipe.py is in the same directory")
        st.stop()

if 'workflow_results' not in st.session_state:
    st.session_state.workflow_results = None

# Sidebar for navigation
st.sidebar.title("🤖 Agent System")
page = st.sidebar.radio(
    "Select Agent",
    ["🏠 Home", "👨‍🍳 Recipe Generator", "🥗 Nutritionist", "📋 Chef Assistant", "🔄 Full Workflow"]
)

st.sidebar.markdown("---")
st.sidebar.markdown("### About")
st.sidebar.info(
    "This multi-agent system uses specialized AI agents to help you "
    "create, analyze, and manage recipes."
)

# Main content
if page == "🏠 Home":
    st.title("🍳 AI Recipe Multi-Agent System")
    st.markdown("""
    Welcome to the intelligent recipe management system powered by multiple specialized agents!
    
    ### Available Agents:
    
    **👨‍🍳 Recipe Generator Agent**
    - Creates recipes based on your ingredients
    - Handles dietary restrictions
    - Customizes cuisine types
    
    **🥗 Nutritionist Agent**
    - Analyzes calorie content
    - Calculates health scores
    - Provides nutritional recommendations
    
    **📋 Chef Assistant Agent**
    - Scales recipes for different servings
    - Suggests ingredient substitutions
    - Generates shopping lists
    
    **🔄 Full Workflow**
    - Runs all agents in sequence
    - Complete recipe creation pipeline
    """)
    
    # Show saved recipes
    st.markdown("---")
    st.subheader("📚 Saved Recipes")
    
    try:
        recipes = st.session_state.orchestrator.storage.list_all()
        if recipes:
            for recipe in recipes:
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write(f"**{recipe['title']}** (ID: {recipe['id']})")
                with col2:
                    if st.button("View", key=f"view_{recipe['id']}"):
                        recipe_data = st.session_state.orchestrator.storage.get(recipe['id'])
                        st.session_state.selected_recipe = recipe_data
        else:
            st.info("No recipes saved yet. Create one using the agents!")
    except Exception as e:
        st.error(f"Error loading recipes: {e}")

elif page == "👨‍🍳 Recipe Generator":
    st.title("👨‍🍳 Recipe Generator Agent")
    st.markdown("Generate creative recipes based on your preferences")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Ingredients")
        include_ingredients = st.text_area(
            "Include ingredients (one per line)",
            placeholder="chicken\nrice\ntomato",
            height=100
        )
        exclude_ingredients = st.text_area(
            "Exclude ingredients (one per line)",
            placeholder="peanuts\nshellfish",
            height=100
        )
    
    with col2:
        st.subheader("Preferences")
        recipe_name = st.text_input("Recipe Name (optional)")
        cuisine = st.selectbox(
            "Cuisine Type",
            ["Italian", "Chinese", "Mexican", "Indian", "French", "Japanese", "Thai", "Mediterranean"]
        )
        servings = st.number_input("Number of Servings", min_value=1, max_value=12, value=4)
        dietary = st.multiselect(
            "Dietary Restrictions",
            ["Vegetarian", "Vegan", "Gluten-Free", "Dairy-Free"]
        )
    
    if st.button("🎨 Generate Recipe", type="primary"):
        include_list = [ing.strip() for ing in include_ingredients.split('\n') if ing.strip()]
        exclude_list = [ing.strip() for ing in exclude_ingredients.split('\n') if ing.strip()]
        
        context = {
            'include_ingredients': include_list,
            'exclude_ingredients': exclude_list,
            'dietary_restrictions': dietary,
            'cuisine': cuisine,
            'name': recipe_name if recipe_name else None,
            'target_servings': servings
        }
        
        with st.spinner("Generating recipe..."):
            result = st.session_state.orchestrator.generator.execute("generate", context)
            
            if result['status'] == 'success':
                st.success(result['message'])
                recipe = result['recipe']
                
                st.markdown("---")
                st.subheader(f"📖 {recipe['title']}")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**🥘 Ingredients:**")
                    for ing in recipe['ingredients']:
                        qty = f"{ing['qty']} {ing['unit']}" if ing['qty'] and ing['unit'] else ""
                        st.write(f"- {ing['name']} {qty}")
                
                with col2:
                    st.markdown(f"**Servings:** {recipe['servings']}")
                    if recipe.get('tags'):
                        st.markdown(f"**Tags:** {', '.join(recipe['tags'])}")
                
                st.markdown("**👩‍🍳 Steps:**")
                for i, step in enumerate(recipe['steps'], 1):
                    st.write(f"{i}. {step}")
                
                # Save option
                if st.button("💾 Save Recipe"):
                    from multi_agent_recipe import RecipeCreateDC, IngredientDC
                    ingredients = [IngredientDC(**ing) for ing in recipe['ingredients']]
                    recipe_obj = RecipeCreateDC(
                        title=recipe['title'],
                        ingredients=ingredients,
                        steps=recipe['steps'],
                        servings=recipe['servings'],
                        tags=recipe['tags']
                    )
                    saved = st.session_state.orchestrator.storage.save(recipe_obj)
                    st.success(f"Recipe saved with ID: {saved.id}")
            else:
                st.error(f"Error: {result.get('message', 'Unknown error')}")

elif page == "🥗 Nutritionist":
    st.title("🥗 Nutritionist Agent")
    st.markdown("Analyze the nutritional content of your recipes")
    
    # Load a recipe
    recipes = st.session_state.orchestrator.storage.list_all()
    
    if recipes:
        selected_recipe_id = st.selectbox(
            "Select a recipe to analyze",
            options=[r['id'] for r in recipes],
            format_func=lambda x: next(r['title'] for r in recipes if r['id'] == x)
        )
        
        if st.button("🔬 Analyze Nutrition", type="primary"):
            recipe_data = st.session_state.orchestrator.storage.get(selected_recipe_id)
            
            context = {'recipe': asdict(recipe_data)}
            
            with st.spinner("Analyzing nutrition..."):
                result = st.session_state.orchestrator.nutritionist.execute("analyze", context)
                
                if result['status'] == 'success':
                    st.success("Analysis complete!")
                    
                    # Display calories
                    col1, col2, col3 = st.columns(3)
                    calories = result['calories']
                    
                    with col1:
                        st.metric("Total Calories", f"{calories['total_calories']:.0f}")
                    with col2:
                        st.metric("Calories/Serving", f"{calories['calories_per_serving']:.0f}")
                    with col3:
                        st.metric("Health Score", f"{result['health_score']}/100")
                    
                    # Detailed breakdown
                    st.markdown("---")
                    st.subheader("📊 Calorie Breakdown by Ingredient")
                    if calories['by_ingredient']:
                        for ing, cals in calories['by_ingredient'].items():
                            st.write(f"**{ing}:** {cals:.0f} calories")
                    else:
                        st.info("No detailed calorie data available for these ingredients")
                    
                    # Recommendations
                    if result.get('recommendations'):
                        st.markdown("---")
                        st.subheader("💡 Recommendations")
                        for rec in result['recommendations']:
                            st.info(rec)
                else:
                    st.error(f"Error: {result.get('message', 'Unknown error')}")
    else:
        st.info("No recipes available. Generate one first!")

elif page == "📋 Chef Assistant":
    st.title("📋 Chef Assistant Agent")
    st.markdown("Scale recipes, find substitutions, and create shopping lists")
    
    task_type = st.radio(
        "Select Task",
        ["Scale Recipe", "Find Substitutions", "Generate Shopping List"]
    )
    
    if task_type == "Scale Recipe":
        st.subheader("📏 Scale Recipe")
        recipes = st.session_state.orchestrator.storage.list_all()
        
        if recipes:
            selected_recipe_id = st.selectbox(
                "Select a recipe",
                options=[r['id'] for r in recipes],
                format_func=lambda x: next(r['title'] for r in recipes if r['id'] == x)
            )
            
            target_servings = st.number_input(
                "Target Servings",
                min_value=1,
                max_value=24,
                value=4
            )
            
            if st.button("⚖️ Scale Recipe", type="primary"):
                recipe_data = st.session_state.orchestrator.storage.get(selected_recipe_id)
                
                context = {
                    'recipe': asdict(recipe_data),
                    'task_type': 'scale',
                    'target_servings': target_servings
                }
                
                result = st.session_state.orchestrator.chef_assistant.execute("scale", context)
                
                if result['status'] == 'success':
                    st.success(result['message'])
                    scaled = result['scaled_recipe']
                    
                    st.markdown("---")
                    st.subheader("🥘 Scaled Ingredients")
                    for ing in scaled['ingredients']:
                        qty = f"{ing['qty']:.2f} {ing['unit']}" if ing['qty'] and ing['unit'] else ""
                        st.write(f"- {ing['name']} {qty}")
        else:
            st.info("No recipes available. Generate one first!")
    
    elif task_type == "Find Substitutions":
        st.subheader("🔄 Find Substitutions")
        
        ingredient = st.text_input("Ingredient to substitute")
        dietary = st.multiselect(
            "Dietary Restrictions",
            ["Vegetarian", "Vegan", "Gluten-Free", "Dairy-Free"]
        )
        
        if st.button("🔍 Find Substitutions", type="primary"):
            context = {
                'ingredient': ingredient,
                'dietary_restrictions': dietary,
                'task_type': 'substitute'
            }
            
            result = st.session_state.orchestrator.chef_assistant.execute("substitute", context)
            
            if result['status'] == 'success':
                st.success(result['message'])
                
                if result['substitutions']:
                    st.markdown("### Possible Substitutions:")
                    for sub in result['substitutions']:
                        st.write(f"✓ {sub}")
                else:
                    st.info(f"No substitutions found for '{ingredient}'")
    
    else:  # Shopping List
        st.subheader("🛒 Generate Shopping List")
        recipes = st.session_state.orchestrator.storage.list_all()
        
        if recipes:
            selected_recipe_id = st.selectbox(
                "Select a recipe",
                options=[r['id'] for r in recipes],
                format_func=lambda x: next(r['title'] for r in recipes if r['id'] == x)
            )
            
            if st.button("📝 Generate List", type="primary"):
                recipe_data = st.session_state.orchestrator.storage.get(selected_recipe_id)
                
                context = {
                    'recipe': asdict(recipe_data),
                    'task_type': 'shopping_list'
                }
                
                result = st.session_state.orchestrator.chef_assistant.execute("shopping", context)
                
                if result['status'] == 'success':
                    st.success(result['message'])
                    
                    st.markdown("---")
                    st.subheader("🛍️ Shopping List")
                    for item, qty in result['shopping_list'].items():
                        qty_str = f"{qty:.2f}" if qty else "as needed"
                        st.write(f"☐ {item}: {qty_str}")
        else:
            st.info("No recipes available. Generate one first!")

else:  # Full Workflow
    st.title("🔄 Complete Recipe Workflow")
    st.markdown("Run all agents in sequence for a complete recipe experience")
    
    with st.form("workflow_form"):
        st.subheader("Recipe Parameters")
        
        col1, col2 = st.columns(2)
        
        with col1:
            include_ingredients = st.text_area(
                "Include ingredients (one per line)",
                placeholder="chicken\nrice\ntomato",
                height=100
            )
            cuisine = st.selectbox(
                "Cuisine Type",
                ["Italian", "Chinese", "Mexican", "Indian", "French"]
            )
        
        with col2:
            servings = st.number_input("Servings", min_value=1, max_value=12, value=4)
            dietary = st.multiselect(
                "Dietary Restrictions",
                ["Vegetarian", "Vegan"]
            )
        
        submitted = st.form_submit_button("🚀 Run Complete Workflow", type="primary")
    
    if submitted:
        include_list = [ing.strip() for ing in include_ingredients.split('\n') if ing.strip()]
        
        context = {
            'include_ingredients': include_list,
            'cuisine': cuisine,
            'target_servings': servings,
            'dietary_restrictions': dietary
        }
        
        with st.spinner("Running complete workflow..."):
            results = st.session_state.orchestrator.create_recipe_workflow(context)
            st.session_state.workflow_results = results
        
        # Display results
        if st.session_state.workflow_results:
            results = st.session_state.workflow_results
            
            st.success("✅ Workflow completed successfully!")
            
            # Recipe
            st.markdown("---")
            st.subheader("👨‍🍳 Generated Recipe")
            if results['generation']['status'] == 'success':
                recipe = results['generation']['recipe']
                st.write(f"**{recipe['title']}**")
                st.write(f"Servings: {recipe['servings']}")
                
                with st.expander("View Full Recipe"):
                    st.markdown("**Ingredients:**")
                    for ing in recipe['ingredients']:
                        qty = f"{ing['qty']} {ing['unit']}" if ing.get('qty') and ing.get('unit') else ""
                        st.write(f"- {ing['name']} {qty}")
                    
                    st.markdown("**Steps:**")
                    for i, step in enumerate(recipe['steps'], 1):
                        st.write(f"{i}. {step}")
            
            # Nutrition
            st.markdown("---")
            st.subheader("🥗 Nutritional Analysis")
            if results['nutrition']['status'] == 'success':
                nutrition = results['nutrition']
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Total Calories", f"{nutrition['calories']['total_calories']:.0f}")
                with col2:
                    st.metric("Per Serving", f"{nutrition['calories']['calories_per_serving']:.0f}")
                with col3:
                    st.metric("Health Score", f"{nutrition['health_score']}/100")
            
            # Shopping List
            st.markdown("---")
            st.subheader("🛒 Shopping List")
            if results['shopping']['status'] == 'success':
                shopping = results['shopping']['shopping_list']
                for item, qty in shopping.items():
                    qty_str = f"{qty:.2f}" if qty else "as needed"
                    st.write(f"☐ {item}: {qty_str}")
            
            st.info(f"Recipe saved with ID: {results['saved_recipe_id']}")

# Footer
st.sidebar.markdown("---")
st.sidebar.markdown("### 🤖 Active Agents")
st.sidebar.write("✓ Recipe Generator")
st.sidebar.write("✓ Nutritionist")
st.sidebar.write("✓ Chef Assistant")