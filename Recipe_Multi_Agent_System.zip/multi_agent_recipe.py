from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
import json
import sqlite3
import os

# Data Classes
@dataclass
class IngredientDC:
    name: str
    qty: Optional[float] = None
    unit: Optional[str] = None

@dataclass
class RecipeCreateDC:
    title: str
    ingredients: List[IngredientDC]
    steps: List[str]
    servings: int = 1
    tags: List[str] = field(default_factory=list)

@dataclass
class RecipeOutDC(RecipeCreateDC):
    id: int = -1

# Constants
CALORIE_DB = {
    "egg": 78,
    "flour": 455,  # per cup
    "milk": 122,   # per cup
    "sugar": 49,   # per tbsp
    "butter": 102, # per tbsp
    "chicken": 165, # per 100g
    "olive oil": 119, # per tbsp
    "rice": 205,   # per cup cooked
    "pasta": 131,  # per 100g
    "tomato": 18,  # per 100g
    "garlic": 4,   # per clove
    "onion": 40,   # per 100g
}

SUBSTITUTIONS = {
    "milk": ["almond milk", "soy milk", "oat milk"],
    "butter": ["olive oil", "margarine", "coconut oil"],
    "egg": ["flax egg", "applesauce"],
    "sugar": ["honey", "maple syrup", "stevia"],
}

DB_PATH = os.path.join(os.path.dirname(__file__) if '__file__' in globals() else '.', 'recipes.db')

# Database Storage
class FallbackDB:
    def __init__(self, path: str = DB_PATH):
        self.path = path
        self._conn: Optional[sqlite3.Connection] = None
        if path == ':memory:':
            self._conn = sqlite3.connect(path, check_same_thread=False)
            self._ensure_schema(self._conn)
        else:
            try:
                parent = os.path.dirname(path)
                if parent and not os.path.exists(parent):
                    os.makedirs(parent, exist_ok=True)
            except Exception:
                pass
            self._ensure_schema()

    def _ensure_schema(self, conn: Optional[sqlite3.Connection] = None) -> None:
        own = False
        if conn is None:
            conn = sqlite3.connect(self.path)
            own = True
        cur = conn.cursor()
        cur.execute('CREATE TABLE IF NOT EXISTS recipes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, metadata TEXT)')
        conn.commit()
        if own:
            conn.close()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        return sqlite3.connect(self.path)

    def save(self, recipe_dc: RecipeCreateDC) -> RecipeOutDC:
        conn = self._get_conn()
        own = conn is not self._conn
        try:
            cur = conn.cursor()
            payload = json.dumps(asdict(recipe_dc))
            cur.execute('INSERT INTO recipes (title, metadata) VALUES (?, ?)', (recipe_dc.title, payload))
            conn.commit()
            rid = cur.lastrowid
            return RecipeOutDC(id=rid, **asdict(recipe_dc))
        finally:
            if own:
                conn.close()

    def get(self, recipe_id: int) -> RecipeOutDC:
        conn = self._get_conn()
        own = conn is not self._conn
        try:
            cur = conn.cursor()
            cur.execute('SELECT id, metadata FROM recipes WHERE id = ?', (recipe_id,))
            row = cur.fetchone()
            if not row:
                raise KeyError('Recipe not found')
            rid, metadata = row
            data = json.loads(metadata)
            ingredients = [IngredientDC(**ing) for ing in data.get('ingredients', [])]
            rc = RecipeCreateDC(
                title=data.get('title', ''),
                ingredients=ingredients,
                steps=data.get('steps', []),
                servings=data.get('servings', 1),
                tags=data.get('tags', [])
            )
            return RecipeOutDC(id=rid, **asdict(rc))
        finally:
            if own:
                conn.close()

    def list_all(self) -> List[Dict[str, Any]]:
        conn = self._get_conn()
        own = conn is not self._conn
        try:
            cur = conn.cursor()
            cur.execute('SELECT id, title FROM recipes')
            rows = cur.fetchall()
            return [{'id': row[0], 'title': row[1]} for row in rows]
        finally:
            if own:
                conn.close()

# Agent Classes
class BaseAgent:
    def __init__(self, name: str):
        self.name = name
    
    def execute(self, command: str, context: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

class RecipeGeneratorAgent(BaseAgent):
    def __init__(self):
        super().__init__("Recipe Generator")
    
    def execute(self, command: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if command == "generate":
            return self._generate(context)
        return {"status": "error", "message": "Unknown command"}
    
    def _generate(self, context: Dict[str, Any]) -> Dict[str, Any]:
        include_ingredients = context.get('include_ingredients', [])
        exclude_ingredients = context.get('exclude_ingredients', [])
        dietary_restrictions = [d.lower() for d in (context.get('dietary_restrictions', []))]
        cuisine = context.get('cuisine', 'Fusion')
        name = context.get('name')
        target_servings = context.get('target_servings', 2)
        
        title = name or f"{cuisine} Dish"
        exclude_set = set(exclude_ingredients)
        
        ingredients: List[Dict] = []
        steps: List[str] = []
        
        if include_ingredients:
            for ing in include_ingredients:
                if ing not in exclude_set:
                    ingredients.append({"name": ing, "qty": 1, "unit": "unit"})
            steps = [
                f"Prepare the following ingredients: {', '.join(include_ingredients)}.",
                "Combine ingredients using standard cooking techniques: sauté, simmer, bake or boil as appropriate.",
                "Season to taste and serve warm."
            ]
        else:
            # Default recipe
            ingredients = [
                {"name": "pasta", "qty": 200, "unit": "g"},
                {"name": "tomato", "qty": 2, "unit": "pcs"},
                {"name": "olive oil", "qty": 2, "unit": "tbsp"},
                {"name": "garlic", "qty": 2, "unit": "cloves"},
            ]
            steps = [
                "Boil the pasta until al dente.",
                "Sauté garlic in olive oil, add chopped tomatoes and simmer.",
                "Toss pasta with sauce and serve."
            ]
        
        # Apply dietary restrictions
        if 'vegan' in dietary_restrictions:
            ingredients = [i for i in ingredients if i['name'].lower() not in ('egg', 'milk', 'butter', 'chicken')]
        if 'vegetarian' in dietary_restrictions:
            ingredients = [i for i in ingredients if i['name'].lower() not in ('chicken', 'beef', 'fish')]
        
        recipe = {
            'title': title,
            'ingredients': ingredients,
            'steps': steps,
            'servings': target_servings,
            'tags': [cuisine] if cuisine else []
        }
        
        return {
            'status': 'success',
            'message': 'Recipe generated successfully',
            'recipe': recipe
        }

class NutritionistAgent(BaseAgent):
    def __init__(self):
        super().__init__("Nutritionist")
    
    def execute(self, command: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if command == "analyze":
            return self._analyze(context)
        return {"status": "error", "message": "Unknown command"}
    
    def _analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        recipe = context.get('recipe', {})
        ingredients = recipe.get('ingredients', [])
        servings = recipe.get('servings', 1)
        
        total = 0
        details: Dict[str, float] = {}
        
        for ing in ingredients:
            name = ing['name'].lower()
            qty = ing.get('qty', 1) or 1
            
            # Estimate calories
            calories = 0
            if name in CALORIE_DB:
                calories = CALORIE_DB[name] * qty
            elif 'flour' in name:
                calories = CALORIE_DB.get('flour', 0) * qty
            elif 'milk' in name:
                calories = CALORIE_DB.get('milk', 0) * qty
            elif any(x in name for x in ['oil', 'butter']):
                calories = 100 * qty
            else:
                calories = 50 * qty  # default estimate
            
            details[ing['name']] = calories
            total += calories
        
        calories_per_serving = total / servings if servings > 0 else 0
        health_score = max(0, min(100, 100 - (calories_per_serving / 10)))
        
        recommendations = []
        if calories_per_serving > 600:
            recommendations.append("Consider reducing portion sizes or using lighter ingredients")
        if calories_per_serving < 300:
            recommendations.append("This is a light meal. Consider adding more protein or vegetables")
        
        return {
            'status': 'success',
            'calories': {
                'total_calories': total,
                'calories_per_serving': calories_per_serving,
                'by_ingredient': details
            },
            'health_score': int(health_score),
            'recommendations': recommendations
        }

class ChefAssistantAgent(BaseAgent):
    def __init__(self):
        super().__init__("Chef Assistant")
    
    def execute(self, command: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if command == "scale":
            return self._scale(context)
        elif command == "substitute":
            return self._substitute(context)
        elif command == "shopping":
            return self._shopping_list(context)
        return {"status": "error", "message": "Unknown command"}
    
    def _scale(self, context: Dict[str, Any]) -> Dict[str, Any]:
        recipe = context.get('recipe', {})
        target_servings = context.get('target_servings', 1)
        original_servings = recipe.get('servings', 1)
        
        if original_servings == 0:
            return {"status": "error", "message": "Original recipe has 0 servings"}
        
        factor = target_servings / original_servings
        
        scaled_ingredients = []
        for ing in recipe.get('ingredients', []):
            qty = ing.get('qty')
            scaled_qty = qty * factor if qty is not None else None
            scaled_ingredients.append({
                'name': ing['name'],
                'qty': scaled_qty,
                'unit': ing.get('unit')
            })
        
        scaled_recipe = {
            'title': recipe.get('title', ''),
            'ingredients': scaled_ingredients,
            'steps': recipe.get('steps', []),
            'servings': target_servings,
            'tags': recipe.get('tags', [])
        }
        
        return {
            'status': 'success',
            'message': f'Recipe scaled to {target_servings} servings',
            'scaled_recipe': scaled_recipe
        }
    
    def _substitute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        ingredient = context.get('ingredient', '').lower()
        dietary_restrictions = [d.lower() for d in context.get('dietary_restrictions', [])]
        
        subs = list(SUBSTITUTIONS.get(ingredient, []))
        
        if 'vegan' in dietary_restrictions:
            subs = [s for s in subs if s.lower() not in ('honey', 'butter')]
        
        return {
            'status': 'success',
            'message': f'Found {len(subs)} substitutions for {ingredient}',
            'substitutions': subs
        }
    
    def _shopping_list(self, context: Dict[str, Any]) -> Dict[str, Any]:
        recipe = context.get('recipe', {})
        ingredients = recipe.get('ingredients', [])
        
        shopping_list: Dict[str, Optional[float]] = {}
        for ing in ingredients:
            name = ing['name']
            qty = ing.get('qty')
            
            if qty is None:
                shopping_list[name] = None
            elif name not in shopping_list or shopping_list[name] is None:
                shopping_list[name] = qty
            else:
                shopping_list[name] += qty
        
        return {
            'status': 'success',
            'message': 'Shopping list generated',
            'shopping_list': shopping_list
        }

# Orchestrator
class RecipeAgentOrchestrator:
    def __init__(self, db_path: str = DB_PATH):
        self.storage = FallbackDB(db_path)
        self.generator = RecipeGeneratorAgent()
        self.nutritionist = NutritionistAgent()
        self.chef_assistant = ChefAssistantAgent()
    
    def create_recipe_workflow(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Run the complete workflow: generate -> analyze -> shopping list"""
        
        # Step 1: Generate recipe
        gen_result = self.generator.execute("generate", context)
        if gen_result['status'] != 'success':
            return {"error": "Recipe generation failed"}
        
        recipe_dict = gen_result['recipe']
        
        # Step 2: Save recipe
        ingredients = [IngredientDC(**ing) for ing in recipe_dict['ingredients']]
        recipe_obj = RecipeCreateDC(
            title=recipe_dict['title'],
            ingredients=ingredients,
            steps=recipe_dict['steps'],
            servings=recipe_dict['servings'],
            tags=recipe_dict['tags']
        )
        saved = self.storage.save(recipe_obj)
        
        # Step 3: Nutritional analysis
        nutrition_context = {'recipe': recipe_dict}
        nutrition_result = self.nutritionist.execute("analyze", nutrition_context)
        
        # Step 4: Shopping list
        shopping_context = {'recipe': recipe_dict}
        shopping_result = self.chef_assistant.execute("shopping", shopping_context)
        
        return {
            'generation': gen_result,
            'nutrition': nutrition_result,
            'shopping': shopping_result,
            'saved_recipe_id': saved.id
        }
