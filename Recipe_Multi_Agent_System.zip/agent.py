from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
import json
import sqlite3
import sys
import os
import traceback

@dataclass
class IngredientDC:
    name: str
    qty: Optional[float] = None
    unit: Optional[str] = None

@dataclass
class RecipeCreateDC:
    title: str
    ingredients: List[IngredientDC]
    steps: List[str]
    servings: int = 1
    tags: List[str] = field(default_factory=list)

@dataclass
class RecipeOutDC(RecipeCreateDC):
    id: int = -1

CALORIE_DB = {
    "egg": 78,
    "flour_cup": 455,
    "milk_cup": 122,
    "sugar_tbsp": 49,
    "butter_tbsp": 102,
    "chicken_100g": 165,
    "olive_oil_tbsp": 119,
    "rice_cup_cooked": 205,
}

SUBSTITUTIONS = {
    "milk": ["almond milk", "soy milk", "oat milk"],
    "butter": ["olive oil", "margarine", "coconut oil"],
    "egg": ["flax egg", "applesauce"],
    "sugar": ["honey", "maple syrup", "stevia"],
}

DB_PATH = os.path.join(os.path.dirname(__file__) if '__file__' in globals() else '.', 'recipes.db')

class FallbackDB:
    def __init__(self, path: str = DB_PATH):
        self.path = path
        self._conn: Optional[sqlite3.Connection] = None
        if path == ':memory:':
            self._conn = sqlite3.connect(path, check_same_thread=False)
            self._ensure_schema(self._conn)
        else:
            try:
                parent = os.path.dirname(path)
                if parent and not os.path.exists(parent):
                    os.makedirs(parent, exist_ok=True)
            except Exception:
                pass
            self._ensure_schema()

    def _ensure_schema(self, conn: Optional[sqlite3.Connection] = None) -> None:
        own = False
        if conn is None:
            conn = sqlite3.connect(self.path)
            own = True
        cur = conn.cursor()
        cur.execute('CREATE TABLE IF NOT EXISTS recipes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, metadata TEXT)')
        conn.commit()
        if own:
            conn.close()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        return sqlite3.connect(self.path)

    def save(self, recipe_dc: RecipeCreateDC) -> RecipeOutDC:
        conn = self._get_conn()
        own = conn is not self._conn
        try:
            cur = conn.cursor()
            payload = json.dumps(asdict(recipe_dc))
            cur.execute('INSERT INTO recipes (title, metadata) VALUES (?, ?)', (recipe_dc.title, payload))
            conn.commit()
            rid = cur.lastrowid
            return RecipeOutDC(id=rid, **asdict(recipe_dc))
        finally:
            if own:
                conn.close()

    def get(self, recipe_id: int) -> RecipeOutDC:
        conn = self._get_conn()
        own = conn is not self._conn
        try:
            cur = conn.cursor()
            cur.execute('SELECT id, metadata FROM recipes WHERE id = ?', (recipe_id,))
            row = cur.fetchone()
            if not row:
                raise KeyError('Recipe not found')
            rid, metadata = row
            data = json.loads(metadata)
            ingredients = [IngredientDC(**ing) for ing in data.get('ingredients', [])]
            rc = RecipeCreateDC(title=data.get('title', ''), ingredients=ingredients, steps=data.get('steps', []), servings=data.get('servings', 1), tags=data.get('tags', []))
            return RecipeOutDC(id=rid, **asdict(rc))
        finally:
            if own:
                conn.close()

class RecipeAgent:
    def __init__(self, storage: FallbackDB):
        self.storage = storage

    def generate(self, include_ingredients: Optional[List[str]] = None, exclude_ingredients: Optional[List[str]] = None,
                 dietary_restrictions: Optional[List[str]] = None, cuisine: Optional[str] = None, name: Optional[str] = None,
                 target_servings: int = 2) -> RecipeCreateDC:
        title = name or (cuisine or "Fusion") + " Dish"
        include_ingredients = include_ingredients or []
        exclude_set = set(exclude_ingredients or [])
        dietary_restrictions = [d.lower() for d in (dietary_restrictions or [])]
        ingredients: List[IngredientDC] = []
        steps: List[str] = []
        for ing in include_ingredients:
            ingredients.append(IngredientDC(name=ing, qty=1, unit="unit"))
        if not ingredients:
            ingredients = [
                IngredientDC(name="pasta", qty=200, unit="g"),
                IngredientDC(name="tomato", qty=2, unit="pcs"),
                IngredientDC(name="olive oil", qty=2, unit="tbsp"),
                IngredientDC(name="garlic", qty=2, unit="cloves"),
            ]
            steps = [
                "Boil the pasta until al dente.",
                "Sauté garlic in olive oil, add chopped tomatoes and simmer.",
                "Toss pasta with sauce and serve.",
            ]
        else:
            steps.append(f"Prepare the following ingredients: {', '.join(i.name for i in ingredients)}.")
            steps.append("Combine ingredients using standard cooking techniques: sauté, simmer, bake or boil as appropriate.")
            steps.append("Season to taste and serve warm.")
        ingredients = [i for i in ingredients if i.name not in exclude_set]
        if 'vegan' in dietary_restrictions:
            ingredients = [i for i in ingredients if i.name.lower() not in ('egg','milk','butter','chicken')]
        if 'vegetarian' in dietary_restrictions:
            ingredients = [i for i in ingredients if i.name.lower() not in ('chicken','beef','fish')]
        return RecipeCreateDC(title=title, ingredients=ingredients, steps=steps, servings=target_servings, tags=[cuisine] if cuisine else [])

    def save_recipe(self, recipe: RecipeCreateDC) -> RecipeOutDC:
        return self.storage.save(recipe)

    def get_recipe(self, recipe_id: int) -> RecipeOutDC:
        return self.storage.get(recipe_id)

    def scale_recipe(self, recipe: RecipeCreateDC, target_servings: int) -> RecipeCreateDC:
        if recipe.servings == 0:
            raise ValueError('Original recipe has 0 servings')
        factor = target_servings / recipe.servings
        scaled: List[IngredientDC] = []
        for ing in recipe.ingredients:
            qty = ing.qty * factor if ing.qty is not None else None
            scaled.append(IngredientDC(name=ing.name, qty=qty, unit=ing.unit))
        return RecipeCreateDC(title=recipe.title, ingredients=scaled, steps=list(recipe.steps), servings=target_servings, tags=list(recipe.tags))

    def substitute(self, ingredient: str, dietary_restrictions: Optional[List[str]] = None) -> List[str]:
        subs = list(SUBSTITUTIONS.get(ingredient.lower(), []))
        dietary_restrictions = [d.lower() for d in (dietary_restrictions or [])]
        if 'vegan' in dietary_restrictions:
            subs = [s for s in subs if s.lower() not in ('honey','butter')]
        return subs

    def shopping_list(self, recipe: RecipeCreateDC) -> Dict[str, Optional[float]]:
        agg: Dict[str, Optional[float]] = {}
        for ing in recipe.ingredients:
            name = ing.name
            qty = ing.qty
            if qty is None:
                agg[name] = None
                continue
            if name not in agg or agg[name] is None:
                agg[name] = qty
            else:
                agg[name] = agg[name] + qty
        return agg

    def estimate_calories(self, recipe: RecipeCreateDC) -> Dict[str, Any]:
        total = 0
        details: Dict[str, float] = {}
        for ing in recipe.ingredients:
            n = ing.name.lower()
            qty = ing.qty if ing.qty is not None else 1
            if n == 'egg':
                per = CALORIE_DB.get('egg', 0)
                details[ing.name] = per * qty
                total += per * qty
            elif 'flour' in n and (ing.unit == 'cup'):
                per = CALORIE_DB.get('flour_cup', 0)
                details[ing.name] = per * qty
                total += per * qty
            elif 'milk' in n and (ing.unit == 'cup'):
                per = CALORIE_DB.get('milk_cup', 0)
                details[ing.name] = per * qty
                total += per * qty
        return {"total_calories": total, "by_ingredient": details}


def run_tests():
    db = FallbackDB(path=':memory:')
    agent = RecipeAgent(db)
    r1 = agent.generate(include_ingredients=['egg','flour'], target_servings=2)
    saved = agent.save_recipe(r1)
    assert saved.id > 0
    fetched = agent.get_recipe(saved.id)
    assert fetched.title == r1.title
    core_rc = RecipeCreateDC(title=fetched.title, ingredients=[IngredientDC(**ing) if isinstance(ing, dict) else ing for ing in fetched.ingredients], steps=fetched.steps, servings=fetched.servings, tags=fetched.tags)
    scaled = agent.scale_recipe(core_rc, 4)
    assert scaled.servings == 4
    subs = agent.substitute('milk', ['vegan'])
    assert 'almond milk' in subs and 'honey' not in subs
    sl = agent.shopping_list(core_rc)
    assert isinstance(sl, dict)
    cal = agent.estimate_calories(core_rc)
    assert 'total_calories' in cal
    extra = RecipeCreateDC(title='test', ingredients=[IngredientDC(name='sugar', qty=2, unit='tbsp'), IngredientDC(name='egg', qty=2, unit=None), IngredientDC(name='milk', qty=1, unit='cup')], steps=['mix'], servings=2)
    saved2 = agent.save_recipe(extra)
    fetched2 = agent.get_recipe(saved2.id)
    sl2 = agent.shopping_list(fetched2)
    assert sl2.get('sugar') == 2
    cal2 = agent.estimate_calories(fetched2)
    assert cal2['total_calories'] >= 0
    assert agent.substitute('unknown') == []
    print('All tests passed')


def main():
    if '--test' in sys.argv:
        try:
            run_tests()
        except Exception:
            traceback.print_exc()
            raise
        return
    if not sys.stdin or not sys.stdin.isatty():
        print('Non-interactive environment detected; use --test to run tests or run in an interactive shell.')
        return
    db = FallbackDB()
    agent = RecipeAgent(db)
    print('Fallback CLI mode. Use --test to run tests or run in a proper environment for web mode.')
    while True:
        try:
            cmd = input('> ').strip().lower()
        except (EOFError, KeyboardInterrupt, OSError):
            print('\nExiting')
            break
        if not cmd:
            continue
        if cmd in ('exit', 'quit'):
            break
        if cmd == 'help':
            print('Commands: gen, list, get <id>, scale <id> <servings>, sub <ingredient>, exit')
            continue
        parts = cmd.split()
        try:
            if parts[0] == 'gen':
                include = parts[1:] if len(parts) > 1 else []
                r = agent.generate(include_ingredients=include)
                saved = agent.save_recipe(r)
                print('Saved recipe id', saved.id)
            elif parts[0] == 'list':
                conn = sqlite3.connect(DB_PATH)
                cur = conn.cursor()
                cur.execute('SELECT id, title FROM recipes')
                rows = cur.fetchall()
                conn.close()
                for row in rows:
                    print(row[0], row[1])
            elif parts[0] == 'get' and len(parts) > 1:
                rid = int(parts[1])
                r = agent.get_recipe(rid)
                print(asdict(r))
            elif parts[0] == 'scale' and len(parts) > 2:
                rid = int(parts[1])
                servings = int(parts[2])
                r = agent.get_recipe(rid)
                core = RecipeCreateDC(title=r.title, ingredients=[IngredientDC(**ing) if isinstance(ing, dict) else ing for ing in r.ingredients], steps=r.steps, servings=r.servings, tags=r.tags)
                scaled = agent.scale_recipe(core, servings)
                print(asdict(scaled))
            elif parts[0] == 'sub' and len(parts) > 1:
                subs = agent.substitute(parts[1])
                print(subs)
            else:
                print('Unknown command')
        except Exception as e:
            print('Error:', e)

if __name__ == '__main__':
    main()

